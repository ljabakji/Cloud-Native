package main

import (
	"gitlab.com/arunravindran/cloudnativecourse/lab6-external-rest-api/weather"
)

func main() {
	weather.RunCLI()
}
